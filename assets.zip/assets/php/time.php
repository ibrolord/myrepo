<?php
//time measurement

$t=time();
echo "$t <br>";




?>