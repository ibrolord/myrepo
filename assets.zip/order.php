<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="en"><head>
        <meta http-equiv="Content-type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<meta name="description" content="">
<meta name="keywords" content="">
                    <link href="images/favicon.ico" rel="shortcut icon" type="image/ico">
                <title>Grace Peters - Restaurant - FoodApp</title>
        <link href="assets/bootstrap.css" rel="stylesheet" type="text/css" id="bootstrap-css">
		<link href="assets/font-awesome.css" rel="stylesheet" type="text/css" id="font-awesome-css">
		<link href="assets/select2.css" rel="stylesheet" type="text/css" id="select2-css">
		<link href="assets/select2-bootstrap.css" rel="stylesheet" type="text/css" id="select2-bootstrap-css">
		<link href="assets/jquery.css" rel="stylesheet" type="text/css" id="jquery-raty-css">
		<link href="assets/fonts.css" rel="stylesheet" type="text/css" id="fonts-css">
		<link href="assets/stylesheet_004.css" rel="stylesheet" type="text/css" id="local-module-css">
		<link href="assets/stylesheet_002.css" rel="stylesheet" type="text/css" id="cart-module-css">
		<link href="assets/stylesheet_003.css" rel="stylesheet" type="text/css" id="categories-module-css">
		<link href="assets/stylesheet.css" rel="stylesheet" type="text/css" id="stylesheet-css">
        
<style type="text/css">body {font-family: "Oxygen",Arial,sans-serif;font-size: 13px;font-weight: normal;font-style: normal;color: #333333;}.menu-name, .panel-default > .panel-heading {color: #333333;}.text-muted { color: #7a7a7a;}body, #page-wrapper {background-color: #ffffff;}.partial .local-box-fluid, .partial .local-box-fluid .panel { background-color: #ed561a; border-color: #ed561a}.step-item .icon i { color: #ed561a; border-color:#ed561a;}.newsletter-subscribe { background-color: #ed561a; color:#333333}.nav-tabs-line > li.active > a, .nav-tabs-line > li.active > a:hover, .nav-tabs-line > li.active > a:focus, .nav-tabs-line > li.open a, .nav-tabs-line > li > a:hover, .nav-tabs-line > li > a:focus,.nav-tabs-line > li.open a, .nav-tabs-line > li:hover, .nav-tabs-line > li:focus, .nav-tabs-line > li.active, .nav-tabs-line > li.active:hover, .nav-tabs-line > li.active:focus { border-bottom-color: #ed561a;}.newsletter-subscribe { color:#333333}#main-header, #main-header .navbar-collapse, .modal-header {background-color: black;}#main-header .dropdown-menu > li > a, .modal-header { color: #ffffff;}#main-header .dropdown-menu { background-color: #ed561a;}#main-header .logo img {height: 40px !important;}#main-header .logo {padding-top: 10px;padding-bottom: 10px;}#main-header .navbar-nav > li > a {font-family: "Oxygen",Arial,sans-serif;font-size: 16px;font-weight: normal;font-style: normal;color: #ffffff;}#main-header .navbar-nav > li > a:focus, #main-header .navbar-nav > li > a:hover, .local-box-fluid h2  {color: #ffffff;}#page-content div.content, div.content .panel, div.content .list-group-item, .modal-content { background-color: #ffffff;}#page-content div.content-wrap { background-color: #ffffff; border-width: 1px; border-style: solid; padding:15px; border-radius:4px;margin-bottom: 20px;}#page-content div.content-wrap, #page-content div.content, #page-content .panel, #page-content .panel .panel-heading, #page-content .nav-tabs, #page-content .list-group-item, #page-content th, #page-content td, #page-content .tab-content-line, .modal-content, #local-information .list-group-item { border-color: #dddddd;}#heading {color: #333333;}.under-heading {background-image: none; height: auto;height: 50px;}.partial .panel {background-color: #ffffff;}.partial .panel, .partial .panel-default > .panel-heading, .partial .panel-cart, #page-content .cart-total .table td,.panel-cart .location-control, .panel-cart .cart-coupon, #local-info .panel-local, .panel-local .panel-heading {border-color: #eeeeee;}.partial .module-box li, .partial > .module-box .list-group-item, #category-box .list-group-item a, .cart-items ul li {background-color: transparent;border-color: #eeeeee; border-width: 0 0 1px; border-style: solid;}.partial .module-box .panel, .partial .list-group-item a, .cart-items ul li .amount, .cart-total .table td,.cart-items ul li .name, .cart-items ul li .name-image:focus .name, .cart-items ul li .name-image:hover .name {color: #484848;}.partial .text-muted { color: #7a7a7a;}a, .btn-link { color: #337ab7;}a:hover, a:focus, .btn-link:focus, .btn-link:hover,#page-footer .main-footer a:hover, #page-footer .main-footer a:focus,#page-footer .bottom-footer a:hover, #page-footer .bottom-footer a:focus,a.list-group-item:hover, .list-group-item > a:hover,.side-bar a.list-group-item.active, .side-bar .list-group-item.active > a,.side-bar a.list-group-item:hover, .side-bar .list-group-item > a:hover,a.list-group-item.active, .list-group-item > a.active { color: #23527c;}.btn-default, .panel-default .panel-heading, .panel-nav-tabs.panel-default .panel-heading {background-color: #e7e7e7;border-color: #e7e7e7;color: #333333;}.btn-default:hover, .btn-default:focus, .btn-default.active, .btn-default:active {background-color: #d3d3d3;border-color: #d3d3d3;color: #1f1f1f;}.btn-primary, .panel-primary .panel-heading, .panel-nav-tabs.panel-primary .panel-heading {background-color: #428bca;border-color: #428bca;color: #ffffff;}.btn-primary:hover, .btn-primary:focus, .btn-primary.active, .btn-primary:active {background-color: #2e77b6;border-color: #2e77b6;color: #ffffff;}.nav-pills > li.active > a {background-color: #428bca;color: #ffffff;}.btn-success, .panel-success .panel-heading, .panel-nav-tabs.panel-success .panel-heading {background-color: #5cb85c;border-color: #5cb85c;color: #ffffff;}.btn-success:hover, .btn-success:focus, .btn-success.active, .btn-success:active {background-color: #48a448;border-color: #48a448;color: #ffffff;}.btn-danger, .panel-danger .panel-heading, .panel-nav-tabs.panel-danger .panel-heading {background-color: #d9534f;color: #ffffff;}.btn-danger:hover, .btn-danger:focus, .btn-danger.active, .btn-danger:active {background-color: #c53f3b;color: #ffffff;}.btn-warning, .panel-warning .panel-heading, .panel-nav-tabs.panel-warning .panel-heading {background-color: #f0ad4e;border-color: #f0ad4e;color: #ffffff;}.btn-warning:hover, .btn-warning:focus, .btn-warning.active, .btn-warning:active {background-color: #dc993a;border-color: #dc993a;color: #ffffff;}.btn-info, .panel-info .panel-heading, .panel-nav-tabs.panel-info .panel-heading {background-color: #5bc0de;border-color: #5bc0de;color: #ffffff;}.btn-info:hover, .btn-info:focus, .btn-info.active, .btn-info:active {background-color: #47acca;border-color: #47acca;color: #ffffff;}#page-footer {background-color: #edeff1; background-image:linear-gradient(to bottom, #edeff1, #edeff1);}#page-footer .bottom-footer {background-color: #fbfbfb;}#page-footer .main-footer, #page-footer .main-footer a, #page-footer .main-footer .footer-title { color: #9ba1a7;}#page-footer .bottom-footer, #page-footer .bottom-footer a, #page-footer .bottom-footer .footer-title { color: #a3aaaf;}</style>
		        <script src="assets/jquery-1.js" charset="utf-8" type="text/javascript" id="jquery-js"></script>
		<script src="assets/bootstrap.js" charset="utf-8" type="text/javascript" id="bootstrap-js"></script>
		<script src="assets/select2.js" charset="utf-8" type="text/javascript" id="select-2-js"></script>
		<script src="assets/jquery.js" charset="utf-8" type="text/javascript" id="jquery-raty-js"></script>
		<script src="assets/jquery_002.js" charset="utf-8" type="text/javascript" id="jquery-mixitup-js"></script>
		<script src="assets/js" charset="utf-8" type="text/javascript" id="google-maps-js"></script>
		<script src="assets/common.js" charset="utf-8" type="text/javascript" id="common-js"></script>        		
		<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
		<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		  <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
                	</head>
	<body class="">
	<header id="main-header">
			<div class="container">
                <div class="row">
                    <div class="col-sm-5">
						<button type="button" class="btn-navbar navbar-toggle" data-toggle="collapse" data-target="#main-header-menu-collapse">
							<i class="fa fa-align-justify"></i>
						</button>
                        <div class="logo">
                            <a class="" >
															Welcome to FoodApp															</a>
						</div>
					</div>
                    <div class="col-sm-7">
						<div class="collapse navbar-collapse" id="main-header-menu-collapse">
							<ul class="nav navbar-nav navbar-right">
																									
							</ul>
						</div>
					</div>
				</div>
			</div>
		</header>
		<div id="opaclayer" onclick="closeReviewBox();"></div>
        <!--[if lt IE 7]>
            <p class="chromeframe">You are using an outdated browser. <a href="http://browsehappy.com/">Upgrade your browser today</a> or <a href="http://www.google.com/chromeframe/?redirect=true">install Google Chrome Frame</a> to better experience this site.</p>
        <![endif]-->

		<div id="page-wrapper" class="content-area">
				            <div id="breadcrumb">
	                <div class="container">
	                    <div class="row">
	                        <div class="col-xs-12">
                                <ol class="breadcrumb"><li class=""><a href="http://funaabconnect.com/demo/"><i class="fa fa-home"></i> </a></li><li class=""><a>Restaurants </a></li><li class="active"><span>Grace Peters </span></li></ol>	                        </div>
	                    </div>
	                </div>
	            </div>
			
            <div id="content-top" class="partial partial-area "><div id="module-local-module-1" class="module-local_module"><div id="local-box">
	<div class="container">
		<div class="row">
			
			<div id="local-alert" class="col-sm-12">
				<div class="local-alert"></div>
							</div>

							<div id="local-info" class="col-md-12" style="display: block">
					<div class="panel panel-local display-local">
												
						
						<div class="panel-body">
							<div class="row boxes">
								<div class="box-one col-xs-12 col-sm-5 col-md-5">
																			<img class="img-responsive pull-left" src="images/IMG-20170627-WA0006.jpg" width="200px" height="80px">
																		<dl class="box-image">
										<dd><h4>Grace Peters</h4></dd>
																					<dd class="text-muted">
												<div class="rating rating-sm">
													<span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star"></span><span class="fa fa-star-half-o"></span><span class="fa fa-star-o"></span>
													<span class="small">(0)</span>
												</div>
											</dd>
																				<dd><span class="text-muted">44 Darnley Road, Greater London E9 6QH</span></dd>
									</dl>
								</div>
								<div class="col-xs-12 box-divider visible-xs"></div>
								<div class="box-two col-xs-12 col-sm-3 col-md-3">
									<dl>
																					<dt><span class="text-success">We are open</span></dt>
																															<dd class="visible-xs">
																									<span class="fa fa-clock-o"></span>&nbsp;&nbsp;<span>24 hours, 7 days.</span>
																							</dd>
																				<dd class="text-muted">
																																				Delivery <span class="text-success">in 20 min</span>																																	</dd>
										<dd class="text-muted">
																																				Pick-up <span class="text-success">in 10 min</span>																																	</dd>
									</dl>
								</div>
								<div class="col-xs-12 box-divider visible-xs"></div>
								<div class="box-three col-xs-12 col-sm-4 col-md-4">
									<dl>
																					<dd class="hidden-xs">
																									<span class="fa fa-clock-o"></span>&nbsp;&nbsp;<span>24 hours, 7 days.</span>
																							</dd>
																				<dd class="text-muted">
																							Delivery and pick-up available																					</dd>
																					<dd class="text-muted">Delivery charge: $10.00 above $100.00, not available below $100.00</dd>
<!--                                            <dd class="text-muted">--><!--</dd>-->
										<!--                                        <dd class="text-muted">--><!--: --><!--</dd>-->
									</dl>
							   </div>
							</div>
						</div>
					</div>
				</div>
					</div>
	</div>
</div>
</div></div>
<div id="page-content">
    <div class="container">
        <div class="row">
            
            <div class="col-sm-8 col-md-9">

                <div class="row wrap-vertical">
                    <ul id="nav-tabs" class="nav nav-tabs nav-tabs-line nav-menus">
                        <li class=""><a href="#local-menus" data-toggle="tab" aria-expanded="true">Menu</a></li>
                                                <li class=""><a href="#local-reviews" data-toggle="tab" aria-expanded="false">Reviews</a></li>
                                                <li class="active"><a href="#local-information" data-toggle="tab" aria-expanded="true">Info</a></li>
                                                <li class=""><a href="#restaurant-gallery" data-toggle="tab" aria-expanded="true">Gallery</a></li>
                                            </ul>
                </div>

                <div class="tab-content tab-content-line content"  style="border-color: white;">
                    <div id="local-menus" class="tab-pane row wrap-all">

                        <div id="content-left" class="partial partial-area col-md-3 hidden-xs hidden-sm"><div id="module-categories-module-1" class="side-bar module-categories_module"><div id="category-box-affix" data-spy="affix" data-offset-top="350" data-offset-bottom="320" class="affix-top" style="width: 196px; position: relative;">
	<div id="category-box" class="module-box">
		
	</div>
</div>
</div></div>
                        <div class="col-sm-12 col-md-9">
                            	<div id="Container" style="padding-left:15%; padding-right:15%;" class="menu-list list">
										<div class="menu-container mix appetizer" style="display: inline-block;">
				<a class="menu-toggle visible-xs visible-sm collapsed" href="#appetizer" role="button" data-toggle="collapse" data-parent=".menu-list" aria-expanded="true" aria-controls="appetizer">
					Appetizer					<i class="fa fa-angle-down fa-2x fa-pull-right text-muted"></i>
					<i class="fa fa-angle-up fa-2x fa-pull-right text-muted"></i>
				</a>
				<div id="appetizer" class="navbar-collapse collapse in wrap-none">
					<div class="menu-category"><hr>
						<h3 class="hidden-xs hidden-sm">Snacks</h3>
						<p></p>
													
											</div>

					 <div class="menu-items">
													
								<div id="menu77" class="menu-item">
									<div class="menu-item-wrapper row">
																					<div class="menu-thumb col-xs-2 col-sm-2 wrap-none wrap-right">
												<img class="img-responsive img-thumbnail" alt="scotch egg" src="images/IMG-20170627-WA0007.jpg">
											</div>
										
										<div class="menu-content col-xs-6 col-sm-6 wrap-none wrap-right">
											<span class="menu-name"><b>Puffpuff</b></span>
											<span class="menu-desc">
												3 pieces<br>Good food is best for your body, especially young ones, not exempting the old ones that desire to stay healthy.											</span>
												
										</div>
										<div class="menu-right col-xs-4 wrap-none">
											<span class="menu-price">$1.00</span>
											<span class="menu-button">
																									<a class="btn btn-primary btn-cart add_cart">
														<span class="fa fa-plus"></span>
													</a>
																							</span>
											
																					</div>
									</div>
								</div>
												
					 </div>
					 <div class="menu-items">
													
								<div id="menu77" class="menu-item">
									<div class="menu-item-wrapper row">
																					<div class="menu-thumb col-xs-2 col-sm-2 wrap-none wrap-right">
												<img class="img-responsive img-thumbnail" alt="scotch egg" src="images/IMG-20170627-WA0018.jpg">
											</div>
										
										<div class="menu-content col-xs-6 col-sm-6 wrap-none wrap-right">
											<span class="menu-name"><b>Chinchin</b></span>
											<span class="menu-desc small">
												A plate of chinchin<br>Good food is best for your body, especially young ones, not exempting the old ones that desire to stay healthy.											</span>
										</div>
										<div class="menu-right col-xs-4 wrap-none">
											<span class="menu-price">$20.00</span>
											<span class="menu-button">
																									<a class="btn btn-primary btn-cart add_cart">
														<span class="fa fa-plus"></span>
													</a>
																							</span>
											
																					</div>
									</div>
								</div>
												
					 </div>
					 <div class="menu-items">
													
								<div id="menu77" class="menu-item">
									<div class="menu-item-wrapper row">
																					<div class="menu-thumb col-xs-2 col-sm-2 wrap-none wrap-right">
												<img class="img-responsive img-thumbnail" alt="scotch egg" src="images/IMG-20170627-WA0018.jpg">
											</div>
										
										<div class="menu-content col-xs-6 col-sm-6 wrap-none wrap-right">
											<span class="menu-name"><b>Egg Roll</b></span>
											<span class="menu-desc small">
												2 pieces<br>Good food is best for your body, especially young ones, not exempting the old ones that desire to stay healthy.											</span>
										</div>
										<div class="menu-right col-xs-4 wrap-none">
											<span class="menu-price">$3.00</span>
											<span class="menu-button">
																									<a class="btn btn-primary btn-cart add_cart">
														<span class="fa fa-plus"></span>
													</a>
																							</span>
											
																					</div>
									</div>
								</div>
													
						<div class="gap"></div>
					 </div>
				</div>
			</div>
											<div class="menu-container mix main-course" style="display: inline-block;">
				<a class="menu-toggle visible-xs visible-sm collapsed" href="#main-course" role="button" data-toggle="collapse" data-parent=".menu-list" aria-expanded="false" aria-controls="main-course">
					Soup and Stew					<i class="fa fa-angle-down fa-2x fa-pull-right text-muted"></i>
					<i class="fa fa-angle-up fa-2x fa-pull-right text-muted"></i>
				</a>
				<div id="main-course" class="navbar-collapse collapse  wrap-none">
					<div class="menu-category">
						<h3 class="hidden-xs hidden-sm">Soup and Stew</h3>
						<p></p>
											</div>

					 <div class="menu-items">
													
								<div id="menu84" class="menu-item">
									<div class="menu-item-wrapper row">
																					<div class="menu-thumb col-xs-2 col-sm-2 wrap-none wrap-right">
												<img class="img-responsive img-thumbnail" alt="eba" src="images/IMG-20170627-WA0008.jpg">
											</div>
										
										<div class="menu-content col-xs-6 col-sm-6 wrap-none wrap-right">
											<span class="menu-name"><b>Soup</b></span>
											<span class="menu-desc small">
												A plate<br>Good food is best for your body, especially young ones, not exempting the old ones that desire to stay healthy.											</span>
										</div>
										<div class="menu-right col-xs-4 wrap-none">
											<span class="menu-price">$20.00</span>
											<span class="menu-button">
																									<a class="btn btn-primary btn-cart add_cart">
														<span class="fa fa-plus"></span>
													</a>
																							</span>
											
																					</div>
									</div>
								</div>
							
								<div id="menu78" class="menu-item">
									<div class="menu-item-wrapper row">
																					<div class="menu-thumb col-xs-2 col-sm-2 wrap-none wrap-right">
												<img class="img-responsive img-thumbnail" alt="ata rice" src="images/IMG-20170627-WA0009.jpg">
											</div>
										
										<div class="menu-content col-xs-6 col-sm-6 wrap-none wrap-right">
											<span class="menu-name"><b>Stew</b></span>
											<span class="menu-desc small">
												A plate<br>Good food is best for your body, especially young ones, not exempting the old ones that desire to stay healthy.											</span>
										</div>
										<div class="menu-right col-xs-4 wrap-none">
											<span class="menu-price">$20.00</span>
											<span class="menu-button">
																									<a class="btn btn-primary btn-cart add_cart">
														<span class="fa fa-plus"></span>
													</a>
																							</span>
											
																					</div>
									</div>
								</div>
							
								<div id="menu79" class="menu-item">
									<div class="menu-item-wrapper row">
																					<div class="menu-thumb col-xs-2 col-sm-2 wrap-none wrap-right">
												<img class="img-responsive img-thumbnail" alt="rice and dodo" src="images/IMG-20170627-WA0010.jpg">
											</div>
										
										<div class="menu-content col-xs-6 col-sm-6 wrap-none wrap-right">
											<span class="menu-name"><b>Meat Ball</b></span>
											<span class="menu-desc small">
												A plate<br>Good food is best for your body, especially young ones, not exempting the old ones that desire to stay healthy.											</span>
										</div>
										<div class="menu-right col-xs-4 wrap-none">
											<span class="menu-price">$20.00</span>
											<span class="menu-button">
																									<a class="btn btn-primary btn-cart add_cart">
														<span class="fa fa-plus"></span>
													</a>
																							</span>
											
																					</div>
									</div>
								</div>
												
						<div class="gap"></div>
					 </div>
				</div>
			</div>
											<div class="menu-container mix salads" style="display: inline-block;">
				<a class="menu-toggle visible-xs visible-sm collapsed" href="#salads" role="button" data-toggle="collapse" data-parent=".menu-list" aria-expanded="false" aria-controls="salads">
					Meat, Chicken and Fish					<i class="fa fa-angle-down fa-2x fa-pull-right text-muted"></i>
					<i class="fa fa-angle-up fa-2x fa-pull-right text-muted"></i>
				</a>
				<div id="salads" class="navbar-collapse collapse  wrap-none">
					<div class="menu-category">
						<h3 class="hidden-xs hidden-sm">Meat, Chicken and Fish</h3>
						<p></p>
											</div>

					 <div class="menu-items">
													
								<div id="menu82" class="menu-item">
									<div class="menu-item-wrapper row">
															<div class="menu-thumb col-xs-2 col-sm-2 wrap-none wrap-right">
												<img class="img-responsive img-thumbnail" alt="seafood salad" src="images/IMG-20170627-WA0022.jpg">
											</div>
										<div class="menu-content col-xs-6 col-sm-6 wrap-none wrap-right">
											<span class="menu-name"><b>Sauced Chicken</b></span>
											<span class="menu-desc small">
												3 pieces<br>Good food is best for your body, especially young ones, not exempting the old ones that desire to stay healthy.											</span>
										</div>
										<div class="menu-right col-xs-4 wrap-none">
											<span class="menu-price">$2.00</span>
											<span class="menu-button">
																									<a class="btn btn-primary btn-cart add_cart">
														<span class="fa fa-plus"></span>
													</a>
																							</span>
											
																					</div>
									</div>
								</div>
							
								<div id="menu83" class="menu-item">
									<div class="menu-item-wrapper row">
																					<div class="menu-thumb col-xs-2 col-sm-2 wrap-none wrap-right">
												<img class="img-responsive img-thumbnail" alt="seafood salad" src="images/IMG-20170627-WA0011.jpg">
											</div>
										
										<div class="menu-content col-xs-6 col-sm-6 wrap-none wrap-right">
											<span class="menu-name"><b>Sauced fish</b></span>
											<span class="menu-desc small">
												1 piece<br>Good food is best for your body, especially young ones, not exempting the old ones that desire to stay healthy.											</span>
										</div>
										<div class="menu-right col-xs-4 wrap-none">
											<span class="menu-price">$1.00</span>
											<span class="menu-button">
																									<a class="btn btn-primary btn-cart add_cart">
														<span class="fa fa-plus"></span>
													</a>
																							</span>
											
																					</div>
									</div>
								</div>
									<div id="menu83" class="menu-item">
									<div class="menu-item-wrapper row">
																					<div class="menu-thumb col-xs-2 col-sm-2 wrap-none wrap-right">
												<img class="img-responsive img-thumbnail" alt="seafood salad" src="images/IMG-20170627-WA0011.jpg">
											</div>
										
										<div class="menu-content col-xs-6 col-sm-6 wrap-none wrap-right">
											<span class="menu-name"><b>Meat Suya</b></span>
											<span class="menu-desc small">
												1 satchet<br>Good food is best for your body, especially young ones, not exempting the old ones that desire to stay healthy.											</span>
										</div>
										<div class="menu-right col-xs-4 wrap-none">
											<span class="menu-price">$15.00</span>
											<span class="menu-button">
																									<a class="btn btn-primary btn-cart add_cart">
														<span class="fa fa-plus"></span>
													</a>
																							</span>
											
																					</div>
									</div>
								</div>			
						<div class="gap"></div>
					 </div>
				</div>
			</div>
											<div class="menu-container mix seafoods" style="display: inline-block;">
				<a class="menu-toggle visible-xs visible-sm collapsed" href="#seafoods" role="button" data-toggle="collapse" data-parent=".menu-list" aria-expanded="false" aria-controls="seafoods">
					Food					<i class="fa fa-angle-down fa-2x fa-pull-right text-muted"></i>
					<i class="fa fa-angle-up fa-2x fa-pull-right text-muted"></i>
				</a>
				<div id="seafoods" class="navbar-collapse collapse  wrap-none">
					<div class="menu-category">
						<h3 class="hidden-xs hidden-sm">Food</h3>
						<p></p>
											</div>

					 <div class="menu-items">
													
								<div id="menu80" class="menu-item">
									<div class="menu-item-wrapper row">
																					<div class="menu-thumb col-xs-2 col-sm-2 wrap-none wrap-right">
												<img class="img-responsive img-thumbnail" alt="special shrimp deluxe" src="images/IMG-20170627-WA0020.jpg">
											</div>
										
										<div class="menu-content col-xs-6 col-sm-6 wrap-none wrap-right">
											<span class="menu-name"><b>White Rice</b></span>
											<span class="menu-desc small">
												A plate<br>Good food is best for your body, especially young ones, not exempting the old ones that desire to stay healthy.											</span>
										</div>
										<div class="menu-right col-xs-4 wrap-none">
											<span class="menu-price">$5.00</span>
											<span class="menu-button">
																									<a class="btn btn-primary btn-cart add_cart">
														<span class="fa fa-plus"></span>
													</a>
																							</span>
											
																					</div>
									</div>
								</div>
												
					 </div>
					 <div class="menu-items">
													
								<div id="menu80" class="menu-item">
									<div class="menu-item-wrapper row">
																					<div class="menu-thumb col-xs-2 col-sm-2 wrap-none wrap-right">
												<img class="img-responsive img-thumbnail" alt="special shrimp deluxe" src="images/IMG-20170627-WA0021.jpg">
											</div>
										
										<div class="menu-content col-xs-6 col-sm-6 wrap-none wrap-right">
											<span class="menu-name"><b>Jollof Rice</b></span>
											<span class="menu-desc small">
												A tray<br>Good food is best for your body, especially young ones, not exempting the old ones that desire to stay healthy.										</span>
										</div>
										<div class="menu-right col-xs-4 wrap-none">
											<span class="menu-price">$35.00</span>
											<span class="menu-button">
																									<a class="btn btn-primary btn-cart add_cart">
														<span class="fa fa-plus"></span>
													</a>
																							</span>
											
																					</div>
									</div>
								</div>
									
					 </div><hr>
				</div>
			</div>
																	
						</div>

	<div class="pager-list"></div>
                        </div>
                    </div>

                                        <div id="local-reviews" class="tab-pane row wrap-all">
                        <div class="col-md-12">
                            <div class="heading-section">
                                <h4>Customer Reviews of Grace Peters</h4>
                                <span class="under-heading"></span>
                            </div>
                        </div>

                        <div class="col-md-12 reviews-list">
    <div class="review-item">
            <p>There are no reviews yet.</p>
        </div>
</div>
                    </div>
                    
                    <div id="local-information"  class="tab-pane row wrap-all active">
                        <div class="col-xs-12">
			<div class="panel panel-default">
			<div class="panel-body">
				<h4 class="wrap-bottom border-bottom">More info about Grace Peters local restaurant</h4>
				<p>Mauris maximus tempor ligula vitae placerat. Proin at orci 
fermentum, aliquam turpis sit amet, ultrices risus. Donec pellentesque 
justo in pharetra rutrum. Cras ac dui eu orci lacinia consequat vitae 
quis sapien. Proin vehicula erat volutpat est tempor, eu feugiat diam 
malesuada. Mauris iaculis ac nisi at euismod. Nunc sit amet luctus 
ipsum. Pellentesque eget lobortis turpis. Vivamus mattis, massa ac 
vulputate vulputate, risus purus tincidunt nibh, vitae pellentesque ex 
nibh at mi. Donec placerat, urna quis interdum tempus, tellus nulla 
commodo leo, vitae auctor orci est congue eros. In vel ex quis orci 
blandit porttitor. Cum sociis natoque penatibus et magnis dis parturient
 montes, nascetur ridiculus mus. Vivamus tincidunt risus non mattis 
semper.</p>
			</div>
		</div>
	</div>

<div class="col-xs-12 wrap-none wrap-bottom">
	<div class="col-xs-12 col-sm-6">
					<div class="panel panel-default panel-nav-tabs">
				<div class="panel-heading">
					<ul class="nav nav-tabs">
						<li class="active"><a href="#opening-hours" data-toggle="tab" aria-expanded="true">Opening Hours</a></li>
													<li><a href="#delivery-hours" data-toggle="tab" aria-expanded="true">Delivery Hours</a></li>
																			<li><a href="#business-card" data-toggle="tab" aria-expanded="true">Business Card</a></li>
											</ul>
				</div>
				<div class="panel-body">
					<div class="tab-content">
													<div id="opening-hours" class="tab-pane fade in active">
								<div class="list-group">
																														<div class="list-group-item">
												<div class="row">
													<div class="col-xs-4">Monday:</div>
													<div class="col-xs-8">
														(00:00 - 23:59)														<span class="small text-muted">24 hours a day</span>
													</div>
												</div>
											</div>
																					<div class="list-group-item">
												<div class="row">
													<div class="col-xs-4">Tuesday:</div>
													<div class="col-xs-8">
														(00:00 - 23:59)														<span class="small text-muted">24 hours a day</span>
													</div>
												</div>
											</div>
																					<div class="list-group-item">
												<div class="row">
													<div class="col-xs-4">Wednesday:</div>
													<div class="col-xs-8">
														(00:00 - 23:59)														<span class="small text-muted">24 hours a day</span>
													</div>
												</div>
											</div>
																					<div class="list-group-item">
												<div class="row">
													<div class="col-xs-4">Thursday:</div>
													<div class="col-xs-8">
														(00:00 - 23:59)														<span class="small text-muted">24 hours a day</span>
													</div>
												</div>
											</div>
																					<div class="list-group-item">
												<div class="row">
													<div class="col-xs-4">Friday:</div>
													<div class="col-xs-8">
														(00:00 - 23:59)														<span class="small text-muted">24 hours a day</span>
													</div>
												</div>
											</div>
																					<div class="list-group-item">
												<div class="row">
													<div class="col-xs-4">Saturday:</div>
													<div class="col-xs-8">
														(00:00 - 23:59)														<span class="small text-muted">24 hours a day</span>
													</div>
												</div>
											</div>
																					<div class="list-group-item">
												<div class="row">
													<div class="col-xs-4">Sunday:</div>
													<div class="col-xs-8">
														(00:00 - 23:59)														<span class="small text-muted">24 hours a day</span>
													</div>
												</div>
											</div>
																											</div>
							</div>
													<div id="delivery-hours" class="tab-pane fade ">
								<div class="list-group">
																			<div class="list-group-item">
											Same as opening hours										</div>
																	</div>
							</div>
													<div id="business-card" class="tab-pane fade ">
								<div class="list-group">
																			<div class="list-group-item">
										
																			<img class="img-responsive pull-left" src="images/IMG-20170627-WA0006.jpg" width="400px" height="400px">
											</div>
																	</div>
							</div>
											</div>
				</div>
			</div>
			</div>

	<div class="col-xs-12 col-sm-6">
		<div class="panel panel-default">
			<div class="panel-body">
				<div class="list-group">
											<div class="list-group-item"><strong>Opens:</strong> 24 hours a day &amp; 7 days a week</div>
																<div class="list-group-item"><i class="fa fa-clock-o fa-fw"></i>&nbsp;<b>Delivery Time</b><br>
															in 20 min													</div>
																<div class="list-group-item"><i class="fa fa-clock-o fa-fw"></i>&nbsp;<b>Pick-up Time</b><br>
															in 10 min													</div>
																<div class="list-group-item"><i class="fa fa-clock-o fa-fw"></i>&nbsp;<b>Last Order Time</b><br>
							11:59 pm						</div>
																<div class="list-group-item"><i class="fa fa-paypal fa-fw"></i>&nbsp;<b>Payments</b><br>
							Cash On Delivery.
						</div>
									</div>
			</div>
		</div>
	</div>

</div>
                 </div>
				 <div id="restaurant-gallery" class="tab-pane row wrap-all">
                        <div class="col-md-12">
                            <div class="heading-section">
                                <h4>Our Gallery of Food</h4>
                                <span class="under-heading"></span>
                            </div>
                        </div>
 <img src="images/IMG-20170627-WA0008.jpg" width="100px" height="100px">
 <img src="images/IMG-20170627-WA0019.jpg" width="100px" height="100px">
 <img src="images/IMG-20170627-WA0009.jpg" width="100px" height="100px">
 <img src="images/IMG-20170627-WA0013.jpg" width="100px" height="100px">
 <img src="images/IMG-20170627-WA0014.jpg" width="100px" height="100px">
 <img src="images/IMG-20170627-WA0015.jpg" width="100px" height="100px">
 <img src="images/IMG-20170627-WA0016.jpg" width="100px" height="100px">
 <img src="images/IMG-20170627-WA0020.jpg" width="100px" height="100px">
 <img src="images/IMG-20170627-WA0022.jpg" width="100px" height="100px">
 <img src="images/IMG-20170627-WA0024.jpg" width="100px" height="100px">

                    </div>

                                    </div>
            </div>
                               </div>
    </div>
</div>
</div>

<footer id="page-footer">
    
    <div class="main-footer">
	    <div class="container">
            <div class="row">
                <div class="col-xs-12 col-sm-3 pull-right">
                                                                <div class="social-bottom">
                            <h4 class="footer-title">Follow us on:</h4>
                            <ul class="social-icons">
                                                                    <li><a class="fa fa-facebook" target="_blank" href="#"></a></li>
                                
                                                                    <li><a class="fa fa-twitter" target="_blank" href="#"></a></li>
                                
                                                                    <li><a class="fa fa-google-plus" target="_blank" href="#"></a></li>
                                
                                                                    <li><a class="fa fa-youtube" target="_blank" href="#"></a></li>
                                
                                
                                
                                
                                
                                
                                
                                
                                                            </ul>
                        </div>
                                    </div>

              
            </div>
        </div>
    </div>

    <div class="bottom-footer">
        <div class="container">
            <div class="row">
                <div class="col-xs-12 wrap-all border-top">
                   
                    &copy; 2017 FoodApp
                    <!-- End powered by -->
                </div>
            </div>
        </div>
	</div>
</footer>

</body></html>